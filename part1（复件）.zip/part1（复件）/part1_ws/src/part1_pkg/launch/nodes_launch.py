
import launch
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

from launch_ros.actions import Node

def generate_launch_description():
    openslam_node = Node(
        package='part1_pkg',
        executable='part1',
        name='openslam',
        output='screen'
    )
    

    # 找到另一个 launch 文件的路径
    other_launch_file = os.path.join(
        get_package_share_directory('fast_lio'),
        'launch',
        'mapping.launch.py'
    )
    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(other_launch_file),
            launch_arguments={'param1': 'value1'}.items()
        ),
        openslam_node
    ])
