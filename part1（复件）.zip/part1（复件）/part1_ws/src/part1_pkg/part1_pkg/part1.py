import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import subprocess
import os
class openslam(Node):
    def __init__(self):
        super().__init__('openslam')
        timer_period = 3.0 
        self.timer = self.create_timer(timer_period, self.timer_callback)


    def timer_callback(self):
        bag_path = '/bags/07-05-10-37'
        subprocess.Popen(['ros2', 'bag', 'play', bag_path])
        self.get_logger().info("slamopen")

        self.timer.cancel()
        

def main(args=None):
    rclpy.init(args=args)
    node = openslam()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()