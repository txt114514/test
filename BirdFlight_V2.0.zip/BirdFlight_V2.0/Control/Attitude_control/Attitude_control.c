/******************** (C) COPYRIGHT 2015-2017 Xiluna Tech ************************
 * ���� 	:Xiluna Tech
 * �ļ��� :Attitude_control.c
 * ����   :�ڻ����ƺ���
 * ����   :http://xiluna.com/
 * ���ں� :XilunaTech
**********************************************************************************/
#include "Attitude_control.h"

AttitudeControl AttitudeControlValue;

void Attitude_control(float PitchCalibration,float RollCalibration)
{	
		static unsigned char YawHover= 0; //�����־λ
    static  float yawErro =0;
    static float AttitudeCycleTime = 0.002f;
		static float GyroxFeedforwardLpf,GyroyFeedforwardLpf,GyrozFeedforwardLpf;
    //���ٶ�ǰ��20hz��ͨ�˲�
    GyroxFeedforwardLpf = (RT_Info.ratePitch - AttitudeControlValue.LastEstimateGyro.x) / AttitudeCycleTime;
    GyroyFeedforwardLpf = (RT_Info.rateRoll - AttitudeControlValue.LastEstimateGyro.y) / AttitudeCycleTime;
    GyrozFeedforwardLpf = (RT_Info.rateYaw - AttitudeControlValue.LastEstimateGyro.z) / AttitudeCycleTime;
	
    GyroxFeedforwardLpf = AttitudeControlValue.LastDerivative.x +
            (AttitudeCycleTime / (7.9577e-3f + AttitudeCycleTime)) * (GyroxFeedforwardLpf - AttitudeControlValue.LastDerivative.x);
    GyroyFeedforwardLpf = AttitudeControlValue.LastDerivative.y +
            (AttitudeCycleTime / (7.9577e-3f + AttitudeCycleTime)) * (GyroyFeedforwardLpf - AttitudeControlValue.LastDerivative.y);
    GyrozFeedforwardLpf = AttitudeControlValue.LastDerivative.z +
            (AttitudeCycleTime / (7.9577e-3f + AttitudeCycleTime)) * (GyrozFeedforwardLpf - AttitudeControlValue.LastDerivative.z);

    AttitudeControlValue.LastEstimateGyro.x = RT_Info.ratePitch;
    AttitudeControlValue.LastEstimateGyro.y = RT_Info.rateRoll;
    AttitudeControlValue.LastEstimateGyro.z = RT_Info.rateYaw;
    AttitudeControlValue.LastDerivative.x = GyroxFeedforwardLpf;
    AttitudeControlValue.LastDerivative.y = GyroyFeedforwardLpf;
    AttitudeControlValue.LastDerivative.z = GyrozFeedforwardLpf;


    float pitchErro = (Target_Info.Pitch-(RT_Info.Pitch -Errangle_Info.fixedErroPitch -PitchCalibration));
    OriginalPitch.value = PID_ParaInfo.Pitch.Kp * pitchErro;
    if(FlightControl.DroneMode!=Drone_Mode_RatePitch)
    {
        UAVThrust.PitchThrust = Limits_data( ( PID_Control(&PID_ParaInfo.PitchRate,&OriginalPitchRate,OriginalPitch.value,RT_Info.ratePitch,0.002,50)) * Inertia_Wx , 0.2f ,-0.2f)
                                    //������
                                    +  Limits_data(  RT_Info.rateRoll * (Inertia_Wz * RT_Info.rateYaw) - (Inertia_Wy * RT_Info.rateRoll) * RT_Info.rateYaw ,0.02f ,-0.02f)
                                                            //���ٶ�ǰ��
                                                            + Limits_data( Inertia_Wx * GyroxFeedforwardLpf , 0.02f ,-0.02f) ;
    }
    else
    {
        UAVThrust.PitchThrust = Limits_data( (  PID_Control(&PID_ParaInfo.PitchRate,&OriginalPitchRate,Target_Info.RatePitch*0.0002f,RT_Info.ratePitch,0.002,150)) * Inertia_Wx , 0.2f ,-0.2f)
                                                //������
                                    + Limits_data(   RT_Info.rateRoll * (Inertia_Wz * RT_Info.rateYaw) - (Inertia_Wy * RT_Info.rateRoll) * RT_Info.rateYaw ,0.02f ,-0.02f)
                                                            //���ٶ�ǰ��
                                                            + Limits_data( Inertia_Wx * GyroxFeedforwardLpf , 0.02f ,-0.02f);
    }

    UAVThrust.PitchThrust =  Limits_data(UAVThrust.PitchThrust,0.2f,-0.2f);


    float rollErro = (Target_Info.Roll-(RT_Info.Roll -Errangle_Info.fixedErroRoll -RollCalibration));
    OriginalRoll.value = PID_ParaInfo.Roll.Kp * rollErro;
    if(FlightControl.DroneMode!=Drone_Mode_RateRoll)
    {
        UAVThrust.RollThrust =  Limits_data(  (  PID_Control(&PID_ParaInfo.RollRate,&OriginalRollRate,OriginalRoll.value,RT_Info.rateRoll,0.002,50)) * Inertia_Wy, 0.2 ,-0.2f)
                                    + Limits_data( (-(RT_Info.ratePitch * (Inertia_Wz * RT_Info.rateYaw) - (Inertia_Wx * RT_Info.ratePitch) * RT_Info.rateYaw)) ,0.02f ,-0.02f)
                                                            //���ٶ�ǰ��
                                                            + Limits_data( Inertia_Wy * GyroyFeedforwardLpf , 0.02f ,-0.02f);
    }
    else
    {
        UAVThrust.RollThrust = Limits_data( (  PID_Control(&PID_ParaInfo.RollRate,&OriginalRollRate,Target_Info.RateRoll*0.0002f,RT_Info.rateRoll,0.002,150)) * Inertia_Wy , 0.2f ,-0.2f)
                                    + Limits_data( (-(RT_Info.ratePitch * (Inertia_Wz * RT_Info.rateYaw) - (Inertia_Wx * RT_Info.ratePitch) * RT_Info.rateYaw)) ,0.02f ,-0.02f)
                                                            //���ٶ�ǰ��
                                                            + Limits_data( Inertia_Wy * GyroyFeedforwardLpf , 0.02f ,-0.02f);
    }

    UAVThrust.RollThrust =  Limits_data(UAVThrust.RollThrust,0.2f,-0.2f);

    if(RockerControl.Navigation == 0)
    {
        if(YawHover ==1)
        {
            Target_Info.Yaw = RT_Info.Yaw;
            YawHover=0;
        }

        //�⻷�Ƕȵ�P����
        if(Target_Info.Yaw - RT_Info.Yaw>=180)
        {
            yawErro=(Target_Info.Yaw - RT_Info.Yaw) - 360 ;
        }
        else if(Target_Info.Yaw - RT_Info.Yaw<-180)
        {
            yawErro=(Target_Info.Yaw - RT_Info.Yaw) + 360 ;
        }
        else
        {
            yawErro=(Target_Info.Yaw - RT_Info.Yaw);
        }
        OriginalYaw.value = PID_ParaInfo.Yaw.Kp * yawErro;
        UAVThrust.YawThrust = Limits_data( (PID_Control(&PID_ParaInfo.YawRate,&OriginalYawRate, OriginalYaw.value ,RT_Info.rateYaw,0.002,50)) * Inertia_Wz , 0.01f ,-0.01f)
                            + Limits_data( RT_Info.ratePitch * (Inertia_Wy * RT_Info.rateRoll) - (Inertia_Wx * RT_Info.ratePitch) * RT_Info.rateRoll ,  0.005f ,-0.005f)
                                                            //���ٶ�ǰ��
                                                            + Limits_data( Inertia_Wz * GyrozFeedforwardLpf ,  0.002f ,-0.002f) ;
    }
    else
    {
        float GyroZErro =  RockerControl.Navigation /50.0f;
        UAVThrust.YawThrust = Limits_data( (PID_Control(&PID_ParaInfo.YawRate,&OriginalYawRate, GyroZErro,RT_Info.rateYaw,0.002,50)) * Inertia_Wz , 0.01f ,-0.01f)
                            + Limits_data( RT_Info.ratePitch * (Inertia_Wy * RT_Info.rateRoll) - (Inertia_Wx * RT_Info.ratePitch) * RT_Info.rateRoll ,  0.005f ,-0.005f)
                                                            //���ٶ�ǰ��
                                                            + Limits_data( Inertia_Wz * GyrozFeedforwardLpf ,  0.002f ,-0.002f);
        YawHover =1;
    }

    UAVThrust.YawThrust =  Limits_data(UAVThrust.YawThrust,0.01f,-0.01f);

    Calculate_Thrust(ARM_Length);
}

void Calculate_Thrust(float arm_length){
	if(FlightControl.DroneMode==Drone_Mode_4Axis)
	{	
		UAVThrust.f1 = - 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust  																		//roll
										- 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust                                  		//pitch
											- 1.0f / (Drag_Coeff * 4.0f) * UAVThrust.YawThrust                                     //yaw	
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;			  											  						//mass		 																									
		
		UAVThrust.f2 = + 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust
										- 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust
											+ 1.0f / (Drag_Coeff * 4.0f) * UAVThrust.YawThrust
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;									

		UAVThrust.f3 = + 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust
										+ 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust
											- 1.0f / (Drag_Coeff * 4.0f) * UAVThrust.YawThrust
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;

		UAVThrust.f4 = - 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust
										+ 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust
											+ 1.0f / (Drag_Coeff * 4.0f) * UAVThrust.YawThrust
											  + UAVThrust.HeightThrust * Drone_Mass / 4.0f;
		
				
	}
	else if(FlightControl.DroneMode==Drone_Mode_Pitch || FlightControl.DroneMode==Drone_Mode_RatePitch)
	{
	  UAVThrust.HeightThrust = 9.794f ;
		
		UAVThrust.f1 = - 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust  																	
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;			  											  					 																									
		
		UAVThrust.f2 = + 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;									

		UAVThrust.f3 = + 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;

		UAVThrust.f4 = - 1.414f / (arm_length * 4.0f) * UAVThrust.PitchThrust
											  + UAVThrust.HeightThrust * Drone_Mass / 4.0f;
	}
	else if(FlightControl.DroneMode==Drone_Mode_Roll || FlightControl.DroneMode==Drone_Mode_RateRoll)
	{
		UAVThrust.HeightThrust = 9.794f ;
		
		UAVThrust.f1 = - 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust                                      
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;			  											  								 																									
		
		UAVThrust.f2 = - 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust									
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;									

		UAVThrust.f3 = + 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust
												+ UAVThrust.HeightThrust * Drone_Mass / 4.0f;

		UAVThrust.f4 = + 1.414f / (arm_length * 4.0f) * UAVThrust.RollThrust
											  + UAVThrust.HeightThrust * Drone_Mass / 4.0f;
	}
	
	UAVThrust.PaddleEffect = 1.0f;
	
	MotorThrust(UAVThrust.f1 * UAVThrust.PaddleEffect,UAVThrust.f2 * UAVThrust.PaddleEffect,UAVThrust.f3 * UAVThrust.PaddleEffect,UAVThrust.f4 * UAVThrust.PaddleEffect);
}


void MotorThrust(float f1,float f2,float f3,float f4){
	
	static float M1,M2,M3,M4 =0;

	/*  ���ı�720���   ��ת�����Űٷֱȹ�ʽ
	 *  M1��M2��M3��M4Ϊ����PWMռ�ձ�
	 *  f1��f2��f3��f4Ϊ�ĸ�������ṩ���� */
	M1 =  1.6321f* f1 + 0.071762f;
	M2 =  1.6321f* f2 + 0.071762f;
	M3 =  1.6321f* f3 + 0.071762f;
	M4 =  1.6321f* f4 + 0.071762f;

	Throttle_Info.M1 = (unsigned int)(M1 * 1000.0f * 8.4f);
	Throttle_Info.M2 = (unsigned int)(M2 * 1000.0f * 8.4f);
	Throttle_Info.M3 = (unsigned int)(M3 * 1000.0f * 8.4f);
	Throttle_Info.M4 = (unsigned int)(M4 * 1000.0f * 8.4f);
	
  
	if(Throttle_Info.M1 > 8000)  Throttle_Info.M1=8000;
	if(Throttle_Info.M2 > 8000)  Throttle_Info.M2=8000;
	if(Throttle_Info.M3 > 8000)  Throttle_Info.M3=8000;
	if(Throttle_Info.M4 > 8000)  Throttle_Info.M4=8000;

	if(Throttle_Info.M1 < 400)  Throttle_Info.M1=400;
	if(Throttle_Info.M2 < 400)  Throttle_Info.M2=400;
	if(Throttle_Info.M3 < 400)  Throttle_Info.M3=400;
	if(Throttle_Info.M4 < 400)  Throttle_Info.M4=400;
	
	
	PWM_OUTPUT(Throttle_Info.M1,Throttle_Info.M2,Throttle_Info.M3,Throttle_Info.M4);
	
}

void PWM_OUTPUT(unsigned int Motor1,
                unsigned int Motor2,
                unsigned int Motor3,
                unsigned int Motor4){
									
	  if(RT_Info.lowPowerFlag==1)
		{
			TIM2->CCR1=0;
			TIM2->CCR2=0;
			TIM2->CCR3=0;
			TIM2->CCR4=0;
		}
		else
		{
			TIM2->CCR1=Motor1;
			TIM2->CCR2=Motor2;
			TIM2->CCR3=Motor3;
			TIM2->CCR4=Motor4;
		}
}



void Safety_Protection(void){
	if(RT_Info.Pitch >=40 || RT_Info.Pitch <= -40 || RT_Info.Roll >= 40 || RT_Info.Roll <= -40){
		PWM_OUTPUT(0,0,0,0);
		while(1);
	}
}




