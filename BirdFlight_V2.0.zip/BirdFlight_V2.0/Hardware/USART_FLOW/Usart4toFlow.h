#ifndef __USART4TOFLOW_H
#define __USART4TOFLOW_H

#include "DronePara.h"
#include "Task.h"
#include <os.h>
#include <string.h>

//extern _Data_Rx Flow; 

void Usart4toFlow_Init(u32 Bound);
void Usart4_tx(uint8_t *data,uint16_t size);

#endif

