#ifndef __TIMER3_AHRS_INNER_H
#define __TIMER3_AHRS_INNER_H

#include "stm32f4xx.h"
#include "Task.h"

void Timer3_Ahrsinit(void);
void Timer4_ImuInnerinit(void);

#endif
