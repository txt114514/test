#ifndef __TIMER3_AHRS_H
#define __TIMER3_AHRS_H
#include "stm32f4xx.h"


void Timer_Ahrsinit(void);

#endif 

