/*
 * I2C.h
 *
 *  Created on: 2019��3��28��
 *      Author: SXJ
 */

#ifndef __I2C_H
#define __I2C_H

#include "stm32f4xx.h"
#include "explore_systick.h"
#include "explore_system.h"

//IO��λ�������궨��
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 

//IST8310
#define SDA_IN()  {GPIOB->MODER&=~(3<<(12*2));GPIOB->MODER|=0<<12*2;}	
#define SDA_OUT() {GPIOB->MODER&=~(3<<(12*2));GPIOB->MODER|=1<<12*2;} 
 
#define IIC_SCL    BIT_ADDR(GPIOB_ODR_Addr,13)  //scl

#define IIC_SDA    BIT_ADDR(GPIOB_ODR_Addr,12)  //��� //SDA
#define READ_SDA   BIT_ADDR(GPIOB_IDR_Addr,12)  //����
 
void IIC_Init(void);
void IIC_Start(void);
void IIC_Stop(void);
unsigned char  IIC_Wait_Ack(void);
unsigned char IIC_Read_Byte(unsigned char ack);
void IIC_Ack(void);
void IIC_NAck(void);
void IIC_Send_Byte(unsigned char txd);
unsigned char IICwriteByte(unsigned char dev, unsigned char reg, unsigned char data);
unsigned char IICreadByte(unsigned char dev, unsigned char reg, unsigned char *data);
unsigned char IICwriteBytes(unsigned char dev, unsigned char reg, unsigned char length, unsigned char* data);
unsigned char IICreadBytes(unsigned char dev, unsigned char reg, unsigned char length, unsigned char *data);
#endif /* SENSOR_I2C_H_ */
