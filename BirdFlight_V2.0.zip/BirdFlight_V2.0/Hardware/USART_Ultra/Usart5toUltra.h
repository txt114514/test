#ifndef __USART5TOULTRA_H
#define __USART5TOULTRA_H

#include "stm32f4xx.h"
#include "DronePara.h"
#include <string.h>
#include <os.h>
#include "Task.h"

void Uart5toTOF_Init(u32 Bound);
void TOF_DataDeal(_Data_Rx rx);


extern _Data_Rx TOF_rx;

#endif
