#ifndef __MCPWM_H
#define __MCPWM_H
#include "stm32f4xx.h"

void PWM_Init(void);

#endif 

