#ifndef __TIMER5_TIMING_H_
#define __TIMER5_TIMING_H_
#include "stdio.h"
#include "stm32f4xx.h"

void Timer5_Timinginit(void);
uint32_t micros(void);

#endif


