/*
 * IST8310.h
 *
 *  Created on: 2019��8��23��
 *      Author: xiluna
 */

#ifndef IST8310_H_
#define IST8310_H_

#include "stm32f4xx.h"
#include "I2C.h"


#define IST8310_SLAVE_ADDRESS     0x0E<<1
#define IST8310_REG_CNTRL1        0x0A  //Control setting register 1

//��ǰ�ų������ֵ����Сֵ
extern int16_t  Mag_maxx,Mag_maxy,Mag_maxz,
		 Mag_minx,Mag_miny,Mag_minz;
extern uint8_t Mag_calib; //��ʼ����ɱ�־uint8_t

void IST8310_Init(void);
void Get_Mag_IST8310(int16_t *mag);
void Mag_Start_Calib(void);
void Mag_Save_Calib(void);


#endif /* SENSOR_IST8310_H_ */
